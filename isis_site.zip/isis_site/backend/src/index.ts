import express from 'express'
import { createServer } from 'http'
import { Server, Socket } from 'socket.io'
import cors from 'cors'

const app = express()
app.use(cors())

const servidorHttp = createServer(app)

const io = new Server(servidorHttp, {
    cors: {
        origin: 'http://localhost:5173',
        methods: ['GET', 'POST'],
    },
})

interface Mensagem {
    texto: string
    remetente: string
    criadoEm: string
}

interface EnviarMensagemPayload {
    salaId: string
    mensagem: Mensagem
}

io.on('connection', (socket: Socket) => {
    console.log('Usuário conectado:', socket.id)

    socket.on('entrarNaSala', (salaId: string) => {
        socket.join(salaId)
        console.log(`Socket ${socket.id} entrou na sala ${salaId}`)
    })

    socket.on('enviarMensagem', ({ salaId, mensagem }: EnviarMensagemPayload) => {
        io.to(salaId).emit('novaMensagem', mensagem)
    })

    socket.on('disconnect', () => {
        console.log('Usuário desconectado:', socket.id)
    })
})

const PORTA = 3001
servidorHttp.listen(PORTA, () => {
    console.log(`Servidor rodando na porta ${PORTA}`)
})