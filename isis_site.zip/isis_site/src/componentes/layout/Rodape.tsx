import estilos from './Rodape.module.css'
// import inicio from '../../assets/icones/casaRoxa.png'
// import botao from '../../assets/icones/botaoRoxo.png'
// import loc from '../../assets/icones/locRoxo.png'
// import chat from '../../assets/icones/chatRoxo.png'
// import diario from '../../assets/icones/diarioRoxo.png'
import { BiHomeAlt } from "react-icons/bi";
import { AiFillAlert } from "react-icons/ai";
import { LuNotebookPen } from "react-icons/lu";
import { IoChatbubbles } from "react-icons/io5";
import { FaLocationDot } from "react-icons/fa6";
import { Link, useLocation } from 'react-router-dom'

export function Rodape() {
    const location = useLocation()
    return (
        <footer className={estilos.conteiner}>

            <Link
                className={estilos.conteinerIcones}
                style={{
                    color: location.pathname === '/principal'
                        ? 'var(--cor-primaria-escura)'
                        : 'var(--cor-secundaria-escura)'
                }}
                to='/principal'
            >
                <BiHomeAlt
                    size={55}
                />
                <p className={estilos.titulo}>Inicial</p>
            </Link>

            <Link
                className={estilos.conteinerIcones}
                style={{
                    color: location.pathname === '/principal/botaoPanico'
                        ? 'var(--cor-primaria-escura)'
                        : 'var(--cor-secundaria-escura)'
                }}
                to='botaoPanico'
            >
                <AiFillAlert
                    size={55}
                />
                <p className={estilos.titulo}>Botão</p>
            </Link>


            <Link
                className={estilos.conteinerIcones}
                style={{
                    color: location.pathname === '/principal/diario'
                        ? 'var(--cor-primaria-escura)'
                        : 'var(--cor-secundaria-escura)'
                }}
                to='diario'
            >
                <LuNotebookPen
                    size={55}
                />
                <p className={estilos.titulo}>Diário</p>
            </Link>

            <Link
                className={estilos.conteinerIcones}
                style={{
                    color: location.pathname === '/principal/chat'
                        ? 'var(--cor-primaria-escura)'
                        : 'var(--cor-secundaria-escura)'
                }}
                to='chat'
            >
                <IoChatbubbles
                    size={55}
                />
                <p className={estilos.titulo}>Chat</p>
            </Link>


            <Link
                className={estilos.conteinerIcones}
                style={{
                    color: location.pathname === '/principal/redesApoio'
                        ? 'var(--cor-primaria-escura)'
                        : 'var(--cor-secundaria-escura)'
                }}
                to='redesApoio'
            >
                <FaLocationDot
                    size={55}
                />
                <p className={estilos.titulo}>Redes</p>
            </Link>
        </footer>
    )
}