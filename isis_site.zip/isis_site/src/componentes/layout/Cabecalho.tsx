import estilos from './Cabecalho.module.css'
import logo from '../../assets/imagens/Logo.png'
import { useContext } from 'react'
import { LayoutContexto } from '../../contextos/LayoutContexto'
import { Link } from 'react-router-dom'
import {useAutenticacao} from '../../hooks/useAutenticacao'


export function Cabecalho() {
    
    const { usuario } = useAutenticacao()

    return (
        <header className={estilos.conteiner}>
            <Link
                to={'/principal'}
            >
                <img
                    className={estilos.imagem}
                    src={logo}
                />
            </Link>

            <div className={estilos.aDireita}>
                <Link
                    to={'/principal'}
                    className={estilos.subTitulo}>
                    Início
                </Link>

                <Link
                    to={'sobre'}
                    className={estilos.subTitulo}>
                    Sobre
                </Link>
                <Link className={estilos.nome}
                to={'perfil'}
                >{`Olá, ${usuario?.nome}`}</Link>
            </div>

        </header>
    )
}
