import estilos from './Menu.module.css'
import { useContext } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { LayoutContexto } from '../../contextos/LayoutContexto'
import { MdMenu, MdMenuOpen, MdLogout } from 'react-icons/md'
import { useAutenticacao } from '../../hooks/useAutenticacao'

export function Menu() {


    const { menuAbertoContexto, setMenuAbertoContexto } = useContext(LayoutContexto)

    const controlarMenu = () => setMenuAbertoContexto(!menuAbertoContexto)


    const navegacao = useNavigate()

    // Obtém a função deslogar
    const {deslogar} = useAutenticacao()

    const sair = async () => {
        await deslogar()
        navegacao('/')
    }

    return (
        <aside
            className={estilos.conteiner}
            style={{ width: menuAbertoContexto ? '175px' : '70px' }}
        >
            <button
                className={estilos.botaoMenu}
                onClick={controlarMenu}
            >
                {menuAbertoContexto ? <MdMenuOpen size={32} /> : <MdMenu size={32} />}
            </button>

            <nav
                className={estilos.itemConteiner}
            >

                <button
                    className={estilos.item}
                    onClick={sair}
                >
                    <MdLogout
                        size={28}
                        color='var(--cor-terciaria-fundo)'
                    />
                    {menuAbertoContexto && <span className={estilos.rotulo}>Sair</span>}
                </button>

            </nav>
        </aside>
    )
}