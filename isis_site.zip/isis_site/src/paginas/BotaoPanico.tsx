import estilos from './BotaoPanico.module.css'
import { Link } from 'react-router-dom'

import botaoAcionar from '../assets/icones/acionar.png'
import escudo from '../assets/icones/escudo.png'
import informacoes from '../assets/icones/informacoes.png'
import telefone from '../assets/icones/telefone.png'

export function BotaoPanico() {
    return (
        <div className={estilos.conteiner}>
            <div className={estilos.conteinerTexto}>
                <Link
                    className={estilos.link}
                    to={'/Principal'}
                >
                    <p className={estilos.subtitulo}>{'< Voltar'}</p>
                </Link>
                <h1 className={estilos.titulo}>Botão de pânico</h1>
                <p className={estilos.subtitulo}>Precisa de ajuda agora? Acione o botão abaixo e <br /> sua localização será enviada para contatos e serviços de emergência.</p>
            </div>

            <div className={estilos.conteinerBotao}>
                <button
                    className={estilos.imagemBotao}>
                    <img src={botaoAcionar} alt="" />
                </button>
            </div>

            <div className={estilos.conteinerCentro}>
                <div className={estilos.conteinerSeguranca}>
                    <img src={escudo}
                        className={estilos.imagem}
                    />
                    <div>
                        <h3 className={estilos.titulo}>Sua segurança é nossa prioridade</h3>
                        <p className={estilos.texto}>Ao acionar o botão, seu contato de confiança e serviços de emergência serão notificados.</p>
                    </div>
                </div>
            </div>

            <div className={estilos.conteinerBranco}>

                <h2 className={estilos.titulo}>Outras formas de pedir ajuda</h2>
                <div className={estilos.conteinerCentro}>

                    <div className={estilos.conteinerSeguranca}>
                        <img src={telefone}
                            className={estilos.imagem}
                        />
                        <div>
                            <h3 className={estilos.titulo}>Ligar para o 180</h3>
                            <p className={estilos.texto}>Central de Atendimento à Mulher</p>
                        </div>
                    </div>

                    <div className={estilos.conteinerSeguranca}>
                        <img src={informacoes}
                            className={estilos.imagem}
                        />
                        <div>
                            <p className={estilos.texto}>O 180 funciona 24h por dia, todos os dias. A ligação é gratuita e sigilosa</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}