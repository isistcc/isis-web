import estilos from './CuidadoComigo.module.css'
import autocuidado from '../assets/icones/autocuidado.png'
import coracaoRosa from '../assets/icones/coracaoRosa.png'
import meditacao from '../assets/icones/meditacao.png'
import sorrisoRosa from '../assets/icones/sorrisoRosa.png'
import estrelaRoxa from '../assets/icones/estrelaRoxa.png'
import { Link } from 'react-router-dom'

export function CuidadoComigo() {
    return (
        <div className={estilos.conteiner}>
            <Link
                to={'/principal/diario'}
                className={estilos.link}
            >
                <p className={estilos.texto}>{'<'} Voltar</p>
            </Link>
            <div className={estilos.conteinerCentro}>

                <div className={estilos.cartaoPrincipal}>
                    <div className={estilos.conteinerIcone}>
                        <img src={autocuidado}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h1 className={estilos.titulo}>Cuidado comigo</h1>
                        <p className={estilos.texto}>Priorize sua saúde mental e física. Reconheça seu valor e pratique autocuidado.</p>
                    </div>
                </div>
            </div>

            <div className={estilos.conteinerCentro}>
                <div className={estilos.cartao}>
                    <div>
                        <h3 className={estilos.titulo}>Sobre essa etapa</h3>
                        <p className={estilos.texto}>O autocuidado é a base  para sua recuperação  e bem-estar. Pequenas ações diárias podem transformar como você se sente e se enxerga. </p>
                    </div>
                </div>
            </div>

            <h2 className={estilos.titulo}>Atividades</h2>

            <div className={estilos.conteinerCentro}>

                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={coracaoRosa}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Pratique o autocuidado</h3>
                        <p className={estilos.texto}>Reserve um momento para refletir sobre suas emoções e necessidades.</p>
                    </div>
                    <input
                        id='autocuidado'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>


                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRoxo}>
                        <img src={meditacao}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Cuide so seu corpo</h3>
                        <p className={estilos.texto}>Alimente-se bem, durma o suficiente e movimente-se no seu ritmo.</p>
                    </div>
                    <input
                        id='corpo'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>

                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={sorrisoRosa}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Momentos de prazer</h3>
                        <p className={estilos.texto}>Faça algo que te dá alegria, mesmo que seja por poucos minutos.</p>
                    </div>
                    <input
                        id='prazer'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>

                <div className={estilos.cartao}>


                    <div className={estilos.conteinerIconesRoxo}>
                        <img src={estrelaRoxa}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Seja gentil consigo mesma</h3>
                        <p className={estilos.texto}>Fale com você coo falaria com alguém que você ama.</p>
                    </div>
                    <input
                        id='gentil'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
            </div>
        </div>
    )
}