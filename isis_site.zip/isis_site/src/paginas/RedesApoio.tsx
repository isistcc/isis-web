import React, { useState, useEffect, useRef } from 'react';
import { type LocalTipo, type FiltrosState, type TipoLocal } from '../tipos/Local'
import estilos from './RedesApoio.module.css';

import { GoogleMap, useJsApiLoader, MarkerF } from '@react-google-maps/api';

const chaveAPI = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;

const centroPadrao = { lat: -22.872237, lng: -47.209565 };

const containerStyle: React.CSSProperties = {
    width: '100%',
    height: '93%',
};

export function RedesApoio() {
    const bibliotecas: ("places")[] = ['places'];

    const { isLoaded } = useJsApiLoader({
        id: 'google-map-script',
        googleMapsApiKey: chaveAPI,
        libraries: bibliotecas,
    });

    const [centro, setCentro] = useState(centroPadrao);
    const containerBuscaRef = useRef<HTMLDivElement>(null);

    const [locais, setLocais] = useState<LocalTipo[]>([]);

    useEffect(() => {
        if (!navigator.geolocation) {
            console.warn('Geolocalização não suportada neste navegador.');
            return; 
        }

        navigator.geolocation.getCurrentPosition(
            (posicao) => {
                setCentro({
                    lat: posicao.coords.latitude,
                    lng: posicao.coords.longitude,
                });
            },
            (erro) => {
                console.warn('Não foi possível obter a localização:', erro.message);
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0,
            }
        );
    }, []); 

    useEffect(() => {
        if (!isLoaded) return;

        const buscarPorTipo = async (
            tipoGoogle: string,
            tipoLocal: TipoLocal
        ): Promise<LocalTipo[]> => {
            const { Place } = await google.maps.importLibrary('places') as google.maps.PlacesLibrary;

            const request = {
                fields: ['displayName', 'location', 'id'],
                locationRestriction: {
                    center: centro,
                    radius: 5000,
                },
                includedPrimaryTypes: [tipoGoogle],
                maxResultCount: 20,
            };

            try {
                const { places: resultados } = await Place.searchNearby(request);

                return resultados
                    .filter((p) => p.location)
                    .map((p) => ({
                        id: p.id,
                        nome: p.displayName ?? 'Sem nome',
                        tipo: tipoLocal,
                        lat: p.location!.lat(),
                        lng: p.location!.lng(),
                    }));
            } catch (erro) {
                console.error(`Erro ao buscar ${tipoGoogle}:`, erro);
                return [];
            }
        };

        const carregarLocais = async () => {
            const [hospitaisAPI, delegaciasAPI, advogadosAPI] = await Promise.all([
                buscarPorTipo('hospital', 'hospitais'),
                buscarPorTipo('police', 'delegacias'),
                buscarPorTipo('lawyer', 'advogados'),
            ]);

            setLocais([...hospitaisAPI, ...delegaciasAPI, ...advogadosAPI]);
        };

        carregarLocais();
    }, [isLoaded, centro]);


    useEffect(() => {
        if (!isLoaded || !containerBuscaRef.current) return;

        let elementoAtivo: HTMLElement | null = null;

        const montarAutocomplete = async () => {
            const { PlaceAutocompleteElement } = await google.maps.importLibrary('places') as google.maps.PlacesLibrary;

            const autocomplete = new PlaceAutocompleteElement();
            elementoAtivo = autocomplete;
            containerBuscaRef.current!.appendChild(autocomplete);

            autocomplete.addEventListener('gmp-select', async (evento: any) => {
                const { placePrediction } = evento;
                const place = placePrediction.toPlace();
                await place.fetchFields({ fields: ['location', 'displayName'] });

                if (place.location) {
                    setCentro({
                        lat: place.location.lat(),
                        lng: place.location.lng(),
                    });
                }
            });
        };

        montarAutocomplete();

        return () => {
            if (elementoAtivo) elementoAtivo.remove();
        };
    }, [isLoaded]);

    const [filtros, setFiltros] = useState<FiltrosState>({
        hospitais: true,
        delegacias: true,
        advogados: true,
    });

    const handleToggle = (chave: keyof FiltrosState) => {
        setFiltros((prev) => ({
            ...prev,
            [chave]: !prev[chave],
        }));
    };

    const locaisFiltrados = locais.filter((local) => filtros[local.tipo]);

    return (
        <div className={estilos.conteiner}>

                <div ref={containerBuscaRef} className={estilos.campoBusca}></div>
            

            <div className={estilos.conteinerMapa}>
                {isLoaded ? (
                    <GoogleMap
                        mapContainerStyle={containerStyle}
                        center={centro}
                        zoom={15}
                    >
                        <MarkerF
                            title='Você está aqui'
                            position={centro}
                        />

                        {locaisFiltrados.map((local) => (
                            <MarkerF
                                key={local.id}
                                position={{ lat: local.lat, lng: local.lng }}
                                title={local.nome}
                            />
                        ))}

                        <div className={estilos.cardFiltros}>
                            <label
                                className={estilos.itemFiltro}
                                style={{ '--cor-toggle': 'var(--cor-primaria-escura)' } as React.CSSProperties}
                            >
                                <input
                                    type="checkbox"
                                    className={estilos.switchInput}
                                    checked={filtros.hospitais}
                                    onChange={() => handleToggle('hospitais')}
                                />
                                <span className={estilos.slider}></span>
                                <span>Hospitais</span>
                            </label>

                            <label
                                className={estilos.itemFiltro}
                                style={{ '--cor-toggle': 'var(--cor-secundaria-base)' } as React.CSSProperties}
                            >
                                <input
                                    type="checkbox"
                                    className={estilos.switchInput}
                                    checked={filtros.delegacias}
                                    onChange={() => handleToggle('delegacias')}
                                />
                                <span className={estilos.slider}></span>
                                <span>Delegacias</span>
                            </label>

                            <label
                                className={estilos.itemFiltro}
                                style={{ '--cor-toggle': 'var(--cor-secundaria-escura)' } as React.CSSProperties}
                            >
                                <input
                                    type="checkbox"
                                    className={estilos.switchInput}
                                    checked={filtros.advogados}
                                    onChange={() => handleToggle('advogados')}
                                />
                                <span className={estilos.slider}></span>
                                <span>Advogados</span>
                            </label>
                        </div>
                    </GoogleMap>
                ) : (
                    <></>
                )}

            </div>
        </div>
    );
}