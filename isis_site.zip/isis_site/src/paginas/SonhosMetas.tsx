import estilos from './SonhosMetas.module.css'
import { Link } from 'react-router-dom'
import estrela from '../assets/icones/estrela.png'
import metas from '../assets/icones/metas.png'
import pegadas from '../assets/icones/pegadas.png'
import livroAberta from '../assets/icones/livroAberta.png'
import relogio from '../assets/icones/relogio.png'
import envelopeAberto from '../assets/icones/envelopeAberto.png'

export function SonhosMetas() {
    return (

        <div className={estilos.conteiner}>
            <Link
                to={'/principal/diario'}
                className={estilos.link}
            >
                <p className={estilos.texto}>{'<'} Voltar</p>
            </Link>
            <div className={estilos.conteinerCentro}>

                <div className={estilos.cartaoPrincipal}>
                    <div className={estilos.conteinerIcone}>
                        <img src={estrela}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h1 className={estilos.titulo}>Novos sonhos e metas</h1>
                        <p className={estilos.texto}>Defina novos sonhos, estabeleça suas metas e alcance o futuro que deseja.</p>
                    </div>
                </div>
            </div>

            <div className={estilos.conteinerCentro}>
                <div className={estilos.cartao}>
                    <div>
                        <h3 className={estilos.titulo}>Sobre essa etapa</h3>
                        <p className={estilos.texto}>Aqui, você pode definir novos sonhos e metas, organizar seus objetivos e acompanhar cada conquista ao longo do seu recomeço.</p>
                    </div>
                </div>
            </div>

            <h2 className={estilos.titulo}>Atividades</h2>

            <div className={estilos.conteinerCentro}>

                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={metas}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Meu maior sonho</h3>
                        <p className={estilos.texto}>Escreva algo que você gostaria de realizar no futuro.</p>
                    </div>
                    <input
                        id='direitos'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>

                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRoxo}>
                        <img src={pegadas}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Pequenos passos</h3>
                        <p className={estilos.texto}>Escolha uma meta e pense em uma pequena ação para começar.</p>
                    </div>
                    <input
                        id='violencia'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>

                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={livroAberta}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Coisas que quero aprender</h3>
                        <p className={estilos.texto}>Liste algo novo que você gostaria de aprender ou experimentar.</p>
                    </div>
                    <input
                        id='ajuda'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRoxo}>
                        <img src={relogio}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Meu futuro ideal</h3>
                        <p className={estilos.texto}>Imagine como gostaria que sua vida estivesse daqui a algum tempo e registre suas ideias.</p>
                    </div>
                    <input
                        id='violencia'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>

                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={envelopeAberto}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Carta para o meu futuro</h3>
                        <p className={estilos.texto}>Escreva uma mensagem para você mesma contando o que espera conquistar.</p>
                    </div>
                    <input
                        id='ajuda'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
            </div>
        </div>
    )
}