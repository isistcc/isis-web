import estilos from './Perfil.module.css'
import { Link, useNavigate } from 'react-router-dom'
import { useAutenticacao } from '../../src/hooks/useAutenticacao'

import logo from '../assets/imagens/Logo.png'
import usuario from '../assets/icones/usuario.png'
import cadeado from '../assets/icones/cadeado.png'
import adicionarUsuario from '../assets/icones/adicionarUsuario.png'
import configuracao from '../assets/icones/configuracao.png'
import userFone from '../assets/icones/userFone.png'
import deixar from '../assets/icones/deixar.png'


export function Perfil() {
    
    const navegacao = useNavigate()

    // Obtém a função deslogar
    const {deslogar} = useAutenticacao()

    const sair = async () => {
        await deslogar()
        navegacao('/')
    }
    
    const conta = () => {
    navegacao('/principal/conta')
}
    const gerenciar = () => {
    navegacao('/principal/gerenciarSenha')
}


    const contato = () => {
    navegacao('/principal/cadastroContato')
}
    return (

        <div className={estilos.conteiner}>
            <Link
                to={'/principal'}
                className={estilos.link}
            >
                <p className={estilos.texto}>{'<'} Voltar</p>
            </Link>
            <div className={estilos.conteinerCentro}>
                <div className={estilos.conteinerImagem}>
                    <img src={logo} className={estilos.imagem} />
                    <h1 className={estilos.titulo}>Fulana de tal</h1>
                </div>

                <button className={estilos.conteinerCartao}
                onClick={conta}
                >
                        <img src={usuario} className={estilos.icones} />
                        <p className={estilos.texto}>Minha conta</p>
                        <p className={estilos.seta}>{'>'}</p>
                </button>

                <button className={estilos.conteinerCartao}
                onClick={gerenciar}>
                        <img src={cadeado} className={estilos.icones} />
                        <p className={estilos.texto}>Gerenciar Senha</p>
                        <p className={estilos.seta}>{'>'}</p>
                </button>
                
                <button className={estilos.conteinerCartao}
                onClick={contato}>
                        <img src={adicionarUsuario} className={estilos.icones} />
                        <p className={estilos.texto}>Contato de Emergência</p>
                        <p className={estilos.seta}>{'>'}</p>
                </button>
                
                <button className={estilos.conteinerCartao}>
                        <img src={configuracao} className={estilos.icones} />
                        <p className={estilos.texto}>Configurações</p>
                        <p className={estilos.seta}>{'>'}</p>
                </button>
                
                <button className={estilos.conteinerCartao}>
                        <img src={userFone} className={estilos.icones} />
                        <p className={estilos.texto}>Central de Ajuda</p>
                        <p className={estilos.seta}>{'>'}</p>
                </button>
                
                <button className={estilos.conteinerCartao}
                    onClick={sair}>
                        <img src={deixar} className={estilos.icones} />
                        <p className={estilos.texto}>Sair</p>
                        <p className={estilos.seta}>{'>'}</p>
                </button>
            </div>
        </div>
    )
}