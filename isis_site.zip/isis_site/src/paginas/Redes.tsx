import estilos from './Redes.module.css'
import { Link } from 'react-router-dom'

import pessoas from '../assets/icones/pessoas.png'
import apoio from '../assets/icones/apoio.png'
import fortaleca from '../assets/icones/fortaleca.png'
import maoCoracao from '../assets/icones/maoCoracao.png'
import usuariosRoxo from '../assets/icones/usuariosRoxo.png'
import maoApoio from '../assets/icones/maoApoio.png'

export function Redes() {
    return (
        <div className={estilos.conteiner}>
            <Link
                to={'/principal/diario'}
                className={estilos.link}
            >
                <p className={estilos.texto}>{'<'} Voltar</p>
            </Link>
            <div className={estilos.conteinerCentro}>

                <div className={estilos.cartaoPrincipal}>
                    <div className={estilos.conteinerIcone}>
                        <img src={pessoas}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h1 className={estilos.titulo}>Rede de apoio</h1>
                        <p className={estilos.texto}>Construa e fortaleça sua rede de apoio com pessoas que te acolhem e te fazem bem.</p>
                    </div>
                </div>
            </div>

            <div className={estilos.conteinerCentro}>
                <div className={estilos.cartao}>
                    <div>
                        <h3 className={estilos.titulo}>Sobre essa etapa</h3>
                        <p className={estilos.texto}>Você não precisa enfrentar tudo sozinha. Ter com quem contar faz toda a diferença na sua jornada. Identifique, aproxime-se e fortaleça sua rede de apoio.</p>
                    </div>
                </div>
            </div>

            <h2 className={estilos.titulo}>Atividades</h2>

            <div className={estilos.conteinerCentro}>
<div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={apoio}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Identifique quem te apoia</h3>
                        <p className={estilos.texto}>Pense nas pessoas que já demonstraram cuidado e que você confia.</p>
                    </div>
                    <input
                        id='apoia'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
                
                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRoxo}>
                        <img src={fortaleca}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Fortaleça seus vinculos</h3>
                        <p className={estilos.texto}>Unvista tempo de qualidade com as pessoas que te fazem bem.</p>
                    </div>
                    <input
                        id='vinculos'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
                
                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={maoCoracao}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Peça ajuda quando precisar</h3>
                        <p className={estilos.texto}>Não tenha medo de pedir ajuda. Você merece e tem direito de ser apoiada.</p>
                    </div>
                    <input
                        id='ajuda'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRoxo}>
                        <img src={usuariosRoxo}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Participe de grupos e comunidades</h3>
                        <p className={estilos.texto}>Conecte-se com grupos que compartilham interesses ou expereiências semelhantes.</p>
                    </div>
                    <input
                        id='comunidades'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
                
                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={maoApoio}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Ofereça apoio também</h3>
                        <p className={estilos.texto}>Ajudar outras pessoas também fortalece sua rede e seu bem -estar.</p>
                    </div>
                    <input
                        id='apoio'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
                
            </div>
        </div>
    )
}