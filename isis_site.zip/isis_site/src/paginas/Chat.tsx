import estilos from './Chat.module.css'
import fone from '../assets/icones/fone.png'
import usuario from '../assets/icones/usuario.png'
import usuarios from '../assets/icones/usuarios.png'
import igualdade from '../assets/icones/igualdade.png'
import { Link, useNavigate } from 'react-router-dom'

export function Chat() {

    const navegacao = useNavigate()

    const atendimentoPsicologico = () => {
        navegacao('/principal/chatPopular/psicologico')
    }

    const orientacaoJuridica = () => {
        navegacao('/principal/chatPopular/juridico')
    }

    const chatPopular = () => {
        navegacao('/principal/chatPopular/popular')
    }

    return (
        <div className={estilos.conteiner}>
            <Link
                to={'/principal'}
                className={estilos.link}
            >
                <p className={estilos.texto}>{'<'} Voltar</p>
            </Link>
            <h1 className={estilos.titulo}>Chat de conversa</h1>
            <p className={estilos.texto}>Converse com alguém de forma segura, acolhedora e confidencial.</p>

            <div className={estilos.conteinerCentro}>

                <div className={estilos.conteinerSeguranca}>
                    <img src={fone}
                        className={estilos.imagem}
                    />
                    <div>
                        <h3 className={estilos.titulo}>Aqui você será ouvida</h3>
                        <p className={estilos.texto}>Nossas conversas são sigilosas e realizadas por profissionais capacitadas para te apoiar.</p>
                    </div>
                </div>
            </div>

            <h2 className={estilos.titulo}>Com quem você deseja conversar?</h2>

            <div className={estilos.conteinerCentro}>

                <button
                    className={estilos.conteinerSeguranca}
                    onClick={atendimentoPsicologico}
                >
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={usuario}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Atendimento psicológico</h3>
                        <p className={estilos.texto}>Converse com psicólogas especializadas e violência contra mulher.</p>
                    </div>
                </button>

                <button
                    className={estilos.conteinerSeguranca}
                    onClick={orientacaoJuridica}
                >
                    <div className={estilos.conteinerIconesRoxo}>
                        <img src={igualdade}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Orientação jurídica</h3>
                        <p className={estilos.texto}>Tire dúvidas sobre seus direitos e medidas protetivas.</p>
                    </div>
                </button>

                <button
                    className={estilos.conteinerSeguranca}
                    onClick={chatPopular}
                >
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={usuarios}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Chat popular</h3>
                        <p className={estilos.texto}>Converse com outras usuárias e compartilhe seus sentimentos e aprendizados.</p>
                    </div>
                </button>
            </div>
        </div>
    )
}