import estilos from './Conhecimento.module.css'
import { Link } from 'react-router-dom'
import livro from '../assets/icones/livro.png'
import balanca from '../assets/icones/balanca.png'
import aviso from '../assets/icones/aviso.png'
import maos from '../assets/icones/maos.png'
import casaLoc from '../assets/icones/casaLoc.png'

export function Conhecimento() {
    return (
        <div className={estilos.conteiner}>
            <Link
                to={'/principal/diario'}
                className={estilos.link}
            >
                <p className={estilos.texto}>{'<'} Voltar</p>
            </Link>
            <div className={estilos.conteinerCentro}>

                <div className={estilos.cartaoPrincipal}>
                    <div className={estilos.conteinerIcone}>
                        <img src={livro}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h1 className={estilos.titulo}>Conhecimento e informação</h1>
                        <p className={estilos.texto}>Aprenda sobre seus direitos, tipos de violência, como se proteger, entre outros.</p>
                    </div>
                </div>
            </div>

            <div className={estilos.conteinerCentro}>
                <div className={estilos.cartao}>
                    <div>
                        <h3 className={estilos.titulo}>Sobre essa etapa</h3>
                        <p className={estilos.texto}>Conhecimento é poder. Enternder o que você vive, conhecer seus direitos e saber onde buscar ajuda são passos importantes para sua segurança e autonomia.</p>
                    </div>
                </div>
            </div>

            <h2 className={estilos.titulo}>Atividades</h2>

            <div className={estilos.conteinerCentro}>

                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={balanca}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Seus direitos</h3>
                        <p className={estilos.texto}>Conheça os principais direitos que te protegem e como acioná-los.</p>
                    </div>
                    <input
                        id='direitos'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
                
                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRoxo}>
                        <img src={aviso}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Tipos de violência</h3>
                        <p className={estilos.texto}>Entenda os diferentes tipos de violência e como identificá-los.</p>
                    </div>
                    <input
                        id='violencia'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
                
                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={maos}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Onde buscar ajuda</h3>
                        <p className={estilos.texto}>Conheça os serviços e canais de apoio disponíveis para você.</p>
                    </div>
                    <input
                        id='ajuda'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
                
                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRoxo}>
                        <img src={casaLoc}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Redes de apoio</h3>
                        <p className={estilos.texto}>Localize delegacias, hospitais e outras redes próximas de você.</p>
                    </div>
                    <input
                        id='apoio'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
            </div>
        </div>
    )
}