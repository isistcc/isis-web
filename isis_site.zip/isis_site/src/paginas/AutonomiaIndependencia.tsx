import estilos from './AutonomiaIndependencia.module.css'
import { Link } from 'react-router-dom'
import maleta from '../assets/icones/maleta.png'
import financeiro from '../assets/icones/financeiro.png'
import desenvolvimento from '../assets/icones/desenvolvimento.png'
import estalar from '../assets/icones/estalar.png'
import direcao from '../assets/icones/direcao.png'

export function AutonomiaIndependencia() {
    return (
        <div className={estilos.conteiner}>
            <Link
                to={'/principal/diario'}
                className={estilos.link}
            >
                <p className={estilos.texto}>{'<'} Voltar</p>
            </Link>
            <div className={estilos.conteinerCentro}>

                <div className={estilos.cartaoPrincipal}>
                    <div className={estilos.conteinerIcone}>
                        <img src={maleta}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h1 className={estilos.titulo}>Autonomia e Independência</h1>
                        <p className={estilos.texto}>Conquiste autonomia financeira, profissional e fortaleça sua indepedência.</p>
                    </div>
                </div>
            </div>

            <div className={estilos.conteinerCentro}>
                <div className={estilos.cartao}>
                    <div>
                        <h3 className={estilos.titulo}>Sobre essa etapa</h3>
                        <p className={estilos.texto}>Ser independente é ter o oder de fazer escolhas e construir a vida que você deseja. Pequenas ações hoje podem gerar grandes mudanças no seu futuro.</p>
                    </div>
                </div>
            </div>

            <h2 className={estilos.titulo}>Atividades</h2>

            <div className={estilos.conteinerCentro}>

                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={financeiro}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Educação financeira</h3>
                        <p className={estilos.texto}>Aprenda a organizar suas finanças, controlar gastos e construir sua liberdade financeira.</p>
                    </div>
                    <input
                        id='educacao'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
                
                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRoxo}>
                        <img src={desenvolvimento}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Desenvolvimento profissional</h3>
                        <p className={estilos.texto}>Descubra suas habilidades, busque qualificações e oportunidades.</p>
                    </div>
                    <input
                        id='desenvolvimento'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
            
               <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRosa}>
                        <img src={estalar}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Vida prática</h3>
                        <p className={estilos.texto}>Aprenda sobre moradia, transporte, saúde e outros aspetos do dia a dia.</p>
                    </div>
                    <input
                        id='pratica'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
                
                <div className={estilos.cartao}>
                    <div className={estilos.conteinerIconesRoxo}>
                        <img src={direcao}
                            className={estilos.imagem}
                        />
                    </div>
                    <div>
                        <h3 className={estilos.titulo}>Tomada de decisão</h3>
                        <p className={estilos.texto}>Desenolva sua autoconfiança para tomar decisões que te aproximem dos seus sonhos.</p>
                    </div>
                    <input
                        id='decisao'
                        className={estilos.checkbox}
                        type="checkbox"
                    />
                </div>
            </div>
        </div>
    )
}