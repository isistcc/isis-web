import estilos from './Login.module.css'
import { useContext, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { LayoutContexto } from '../contextos/LayoutContexto'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { type UsuarioTipo } from '../tipos/Usuario'
import email from '../assets/icones/email.png'
import cadeado from '../assets/icones/cadeado.png'
import google from '../assets/icones/google.png'
import facebook from '../assets/icones/facebook.webp'
import { ModalMensagem } from '../componentes/ModalMensagem'
import { useAutenticacao } from '../hooks/useAutenticacao'

type FormValues = {
    email: string
    senha: string
}

const loginSchema = z.object({

    email: z.email({ message: 'Informe um e-mail válido.' }),

    senha: z.string()
        .length(6, { message: 'Informe uma senha com 6 caracteres.' })
})

export function Login() {

    const [modalMensagemVisivel, setModalMensagemVisivel] = useState(false)
    const [modalMensagemTitulo, setModalMensagemTitulo] = useState('')
    const [modalMensagemTexto, setModalMensagemTexto] = useState('')

    const exibirModal = () => {
        setModalMensagemTitulo('Autenticação')
        setModalMensagemVisivel(true)
    }

    const ocultarModal = () => setModalMensagemVisivel(false)

    const { 
        register, handleSubmit, formState:{errors} 
    } = useForm<FormValues>(
        {resolver: zodResolver(loginSchema)}
    )

    const navegacao = useNavigate()

    const dadosUsuario: UsuarioTipo = {
        email: '',
        senha: ''
    }

    // Cria o objeto de autenticação
    const autenticacao = useAutenticacao()

    const autenticarUsuario = async (data: FormValues) => {

        dadosUsuario.email = data.email
        dadosUsuario.senha = data.senha

        let retorno = await autenticacao.validarUsuario(data.email, data.senha)

        if(retorno == 'sucesso'){
            navegacao('principal')
        }else{
            setModalMensagemTexto(retorno)
            exibirModal()
        }

    }

    return (
        <div className={estilos.conteiner}>

            <div className= {estilos.aDireita}>
                <p className={estilos.subTitulo}>Ainda não possui uma conta?</p>
                <Link
                    className={estilos.link}
                    to={'usuario'}
                    >
                    <p>Cadastrar</p>
                </Link>
            </div>

            <h1 className={estilos.titulo}>Login</h1>

            <p className={estilos.subTitulo}>Preencha seus dados para entrar</p>

            <form 
                className={estilos.formulario}
                onSubmit={handleSubmit(autenticarUsuario)}
            >
                
                <div>
                    <p className={estilos.tituloCampo}>E-mail</p>
                    <div
                        className={estilos.campo}>
                        <img 
                        className={estilos.icones}
                        src={email} />
                        <input
                            {...register('email')}
                            className={estilos.texto}
                            placeholder='Digite seu melhor e-mail'
                        />
                    </div>
                    {errors.email && <p className={estilos.mensagem}>{errors.email.message}</p>}
                </div>

                <div>
                    <p className={estilos.tituloCampo}>Senha</p>
                    <div
                        className={estilos.campo}>
                            <img
                            className={estilos.icones}
                            src={cadeado} />
                        <input
                            {...register('senha')}
                            className={estilos.texto}
                            placeholder='Crie uma senha segura'
                            type='password'
                        />
                    </div>
                    {errors.senha && <p className={estilos.mensagem}>{errors.senha.message}</p>}
                </div>
            <div className= {estilos.aDireita}>
                <p className={estilos.subTitulo}>Esqueci minha senha</p>
            </div>

                <button 
                    className={estilos.botao}
                >
                    Entrar
                </button>                
            </form>

<button className={estilos.campo}>
                <img
                            className={estilos.icones}
                            src={google} />
                Continuar com Google
            </button>
            <button className={estilos.campo}>
                <img
                            className={estilos.icones}
                            src={facebook} />
                Continuar com Facebook
            </button>

            <ModalMensagem 
                exibir={modalMensagemVisivel}
                ocultar={() => ocultarModal()}
                titulo={modalMensagemTitulo}
                texto={modalMensagemTexto}
            />
        </div>
    )
}