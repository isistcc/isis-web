import estilos from './NovoUsuario.module.css'
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { ModalMensagem } from '../componentes/ModalMensagem'
import { type UsuarioTipo } from '../tipos/Usuario'
import usuario from '../assets/icones/usuario.png'
import email from '../assets/icones/email.png'
import cadeado from '../assets/icones/cadeado.png'
import escudo from '../assets/icones/escudo.png'
import google from '../assets/icones/google.png'
import facebook from '../assets/icones/facebook.webp'
import { useAutenticacao } from '../hooks/useAutenticacao'

type FormValues = {
    nome: string
    email: string
    senha: string
}

const loginSchema = z.object({

    nome: z.string()
        .min(2, 'Mínimo de 2 caracteres.')
        .max(25, 'Máximo de 25 caracteres.'),

    email: z.email({ message: 'Informe um e-mail válido.' }),

    senha: z.string()
        .length(6, { message: 'Informe uma senha com 6 caracteres.' })
})

export function NovoUsuario() {

    const [modalMensagemVisivel, setModalMensagemVisivel] = useState(false)
    const [modalMensagemTitulo, setModalMensagemTitulo] = useState('')
    const [modalMensagemTexto, setModalMensagemTexto] = useState('')

    const {
        register, handleSubmit, formState: { errors }
    } = useForm<FormValues>(
        { resolver: zodResolver(loginSchema) }
    )

    const navegacao = useNavigate()

    const dadosUsuario: UsuarioTipo = {
        nome: '',
        email: '',
        senha: ''
    }

    // Cria o objeto de autenticação
    const autenticacao = useAutenticacao()

    const adicionarUsuario = async (data: FormValues) => {

        dadosUsuario.nome = data.nome
        dadosUsuario.email = data.email
        dadosUsuario.senha = data.senha

        // Cria a autenticação do usuário (Authentication)
        let retorno = await autenticacao.criarAutenticacaoUsuario(data.email, data.senha)

        if (retorno == 'sucesso') {
            setModalMensagemTexto(`Seja bem-vindo ${dadosUsuario.nome}!`)
        }else {
            setModalMensagemTexto(retorno)
        }

        exibirModal()
    }

    const exibirModal = () => {
        setModalMensagemTitulo('Novo usuário')
        setModalMensagemVisivel(true)
    }

    const ocultarModal = async () => {

        setModalMensagemVisivel(false)

        // Garente que ao logar os dados estarão completos
        await autenticacao.deslogar()

        navegacao('/')
    }

    return (
        <div className={estilos.conteiner}>
            <div className={estilos.aDireita}>
                <p className={estilos.subTitulo}>Já tem uma conta? </p>
                <Link

                    className={estilos.link}
                    to={'/'}
                >
                    <p>Entrar</p>
                </Link>
            </div>

            <h1 className={estilos.titulo}>Criar conta</h1>
            <p className={estilos.subTitulo}>Preencha seus dados para se cadastrar</p>

            <form
                className={estilos.formulario}
                onSubmit={handleSubmit(adicionarUsuario)}
            >
                <div>
                    <p className={estilos.tituloCampo}>Nome</p>
                    <div className={estilos.campo}>
                        <img
                            className={estilos.icones}
                            src={usuario} />
                        <input
                            className={estilos.texto}
                            {...register('nome')}
                            placeholder='Digite seu nome completo'
                        />

                    </div>
                    {errors.nome && <p className={estilos.mensagem}>{errors.nome.message}</p>}
                </div>

                <div>
                    <p className={estilos.tituloCampo}>E-mail</p>
                    <div
                        className={estilos.campo}>
                        <img
                            className={estilos.icones}
                            src={email} />
                        <input
                            {...register('email')}
                            className={estilos.texto}
                            placeholder='Digite seu melhor e-mail'
                        />
                    </div>
                    {errors.email && <p className={estilos.mensagem}>{errors.email.message}</p>}
                </div>

                <div>
                    <p className={estilos.tituloCampo}>Senha</p>
                    <div
                        className={estilos.campo}>
                        <img
                            className={estilos.icones}
                            src={cadeado} />
                        <input
                            {...register('senha')}
                            className={estilos.texto}
                            placeholder='Crie uma senha segura'
                            type='password'
                        />
                    </div>
                    {errors.senha && <p className={estilos.mensagem}>{errors.senha.message}</p>}
                </div>
                <div className={estilos.seguranca}>
                    <img
                        className={estilos.imagem}
                        src={escudo}
                    />
                    <div>
                    <p className={estilos.tituloCampo}>Sua segurança é nossa prioridade</p>
                    <p>Seus dados são protegidos e nunca serão compartilhados.</p>
                    </div>
                </div>

                <button className={estilos.botao}>
                    Cadastrar
                </button>
            </form>

            <button className={estilos.campo}>
                <img
                    className={estilos.icones}
                    src={google} />
                Continuar com Google
            </button>
            <button className={estilos.campo}>
                <img
                    className={estilos.icones}
                    src={facebook} />
                Continuar com Facebook
            </button>
            <ModalMensagem
                exibir={modalMensagemVisivel}
                ocultar={() => ocultarModal()}
                titulo={modalMensagemTitulo}
                texto={modalMensagemTexto}
            />

        </div>
    )
}
