import { useState, useEffect, useRef } from 'react'
import { useParams } from 'react-router-dom'
import { io, Socket } from 'socket.io-client'
import { type Mensagem } from '../tipos/Mensagem'
import { useAutenticacao } from '../hooks/useAutenticacao'
import estilos from './Chat.module.css'

export function ChatSala() {
    const { salaId } = useParams<{ salaId: string }>()
    const { usuario, carregando } = useAutenticacao()
    const meuId = usuario?.codigo

    const [mensagens, setMensagens] = useState<Mensagem[]>([])
    const [textoInput, setTextoInput] = useState('')
    const socketRef = useRef<Socket | null>(null)
    const finalDaListaRef = useRef<HTMLDivElement>(null)

    useEffect(() => {
        if (!salaId || !meuId) return

        socketRef.current = io(import.meta.env.VITE_SOCKET_URL)

        socketRef.current.emit('entrarNaSala', salaId)

        socketRef.current.on('novaMensagem', (mensagem: Mensagem) => {
            setMensagens((anterior) => [...anterior, mensagem])
        })

        return () => {
            socketRef.current?.disconnect()
        }
    }, [salaId, meuId])

    useEffect(() => {
        finalDaListaRef.current?.scrollIntoView({ behavior: 'smooth' })
    }, [mensagens])

    const enviarMensagem = (evento: React.FormEvent) => {
        evento.preventDefault()
        if (!textoInput.trim() || !socketRef.current || !salaId || !meuId) return

        const mensagem: Mensagem = {
            texto: textoInput,
            remetente: meuId,
            criadoEm: new Date().toISOString(),
        }

        socketRef.current.emit('enviarMensagem', { salaId, mensagem })
        setTextoInput('')
    }

    if (carregando) {
        return <p className={estilos.aviso}>Carregando...</p>
    }

    if (!salaId) {
        return <p className={estilos.aviso}>Sala de chat não encontrada.</p>
    }

    if (!meuId) {
        return <p className={estilos.aviso}>Você precisa estar logada para acessar o chat.</p>
    }

    return (
        <div className={estilos.conteiner}>
            <div className={estilos.listaMensagens}>
                {mensagens.map((mensagem, indice) => (
                    <div
                        key={indice}
                        className={
                            mensagem.remetente === meuId
                                ? estilos.mensagemEnviada
                                : estilos.mensagemRecebida
                        }
                    >
                        <p>{mensagem.texto}</p>
                    </div>
                ))}
                <div ref={finalDaListaRef} />
            </div>

            <form className={estilos.formularioEnvio} onSubmit={enviarMensagem}>
                <input
                    type="text"
                    value={textoInput}
                    onChange={(evento) => setTextoInput(evento.target.value)}
                    placeholder="Digite sua mensagem..."
                    className={estilos.campoTexto}
                />
                <button type="submit" className={estilos.botaoEnviar}>
                    Enviar
                </button>
            </form>
        </div>
    )
}