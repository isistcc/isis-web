import estilos from './Inicial.module.css';
import { Link } from 'react-router-dom';
import mulheres from '../assets/imagens/mulheres.png';
import botao from '../assets/icones/botaoRosa.png';
import loc from '../assets/icones/loc.png';
import diario from '../assets/icones/diario.png';
import chat from '../assets/icones/chatRosa.png';
import tipos from '../assets/icones/tipos.png';
import leis from '../assets/icones/leis.png';
import denunciar from '../assets/icones/denunciar.png';
import escudo from '../assets/icones/escudo2.png';
import balaoMensagem from '../assets/icones/balaoMensagem.png';


export function Inicial() {
    return (
        <main>
            <section className={estilos.conteiner1}>
                <div className={estilos.conteinerTxtBtn}>
                    <h1 className={estilos.titulo}>Você não está sozinha.</h1>
                    <p className={estilos.subtitulo}>
                        A plataforma Ísis foi criada para apoiar mulheres que passaram por qualquer tipo de violência.
                        <br /><br />
                        Aqui você encontra ajuda, informação e acolhimento.
                    </p>

                    <div className={estilos.conteinerBotoes}>
                        <button className={estilos.botaoRosa}>
                            <img src={escudo} className={estilos.icone}/>
                            Preciso de ajuda
                        </button>

                        <button className={estilos.botaoRoxo}>
                            <img src={balaoMensagem} className={estilos.icone} />
                            Falar com alguém
                        </button>
                    </div>

                </div>

                <div className={estilos.conteinerImagem}>
                    <img
                        className={estilos.imagem}
                        src={mulheres}
                    />
                </div>
            </section>

            <section className={estilos.conteiner2}>
                <h1 className={estilos.titulo}>Acesso rápido</h1>
                <div className={estilos.lista}>
                    <div className={estilos.conteinerAcesso}>
                        <Link
                            className={estilos.link}
                            to={'botaoPanico'}>
                            <div className={estilos.conteinerImagemAcesso}>
                                <img src={botao} alt=""
                                    className={estilos.icones}
                                />
                            </div>
                            <h2>Botão de pânico</h2>
                            <p className={estilos.texto}>Pressione quando necessário</p>
                        </Link>
                    </div>


                    <div className={estilos.conteinerAcesso}>
                        <Link
                            className={estilos.link}
                            to={'diario'}>
                            <div className={estilos.conteinerImagemAcesso}>
                                <img src={diario} alt=""
                                    className={estilos.icones}
                                />
                            </div>
                            <h2>Diário digital</h2>
                            <p className={estilos.texto}>Registre seus dias e progresso</p>
                        </Link>
                    </div>
                    <div className={estilos.conteinerAcesso}>
                        <Link
                            className={estilos.link}
                            to={'chat'}>
                            <div className={estilos.conteinerImagemAcesso}>
                                <img src={chat} alt=""
                                    className={estilos.icones}
                                />
                            </div>
                            <h2>Chat de conversa</h2>
                            <p className={estilos.texto}>Converse com aquelas que te entendem</p>
                        </Link>
                    </div>
                    <div className={estilos.conteinerAcesso}>
                        <Link
                            className={estilos.link}
                            to={'redesApoio'}>
                            <div className={estilos.conteinerImagemAcesso}>
                                <img src={loc} alt=""
                                    className={estilos.icones}
                                />
                            </div>
                            <h2>Redes de Apoio</h2>
                            <p className={estilos.texto}>Encontre serviços de apoio da sua região</p>
                        </Link>
                    </div>
                </div>
            </section>


            <section className={estilos.conteiner3}>
                <h1 className={estilos.titulo}>Informações que protegem</h1>
                <div className={estilos.lista}>

                    <div className={estilos.conteinerInformacoes}>
                        <Link
                            className={estilos.link2}
                            to={'informacoes'}>
                            <div className={estilos.conteinerImagemInfo}>
                                <img src={tipos} alt="" className={estilos.icones} />
                            </div>
                            <div>
                                <h2 className={estilos.titulo}>Tipos de violência</h2>
                                <p className={estilos.texto}>Entenda os diferentes tipos de violência.</p>
                            </div>
                        </Link>
                    </div>

                    <div className={estilos.conteinerInformacoes}>
                        <Link
                            className={estilos.link2}
                            to={'informacoes'}>
                            <div className={estilos.conteinerImagemInfo}>
                                <img src={leis} alt="" className={estilos.icones} />
                            </div>
                            <div>
                                <h2 className={estilos.titulo}>Leis & Direitos</h2>
                                <p className={estilos.texto}>Conheça seus direitos e como a lei te protege.</p>
                            </div>
                        </Link>
                    </div>

                    <div className={estilos.conteinerInformacoes}>
                        <Link
                            className={estilos.link2}
                            to={'informacoes'}>
                            <div className={estilos.conteinerImagemInfo}>
                                <img src={denunciar} alt="" className={estilos.icones} />
                            </div>
                            <div>
                                <h2 className={estilos.titulo}>Como denunciar</h2>
                                <p className={estilos.texto}>Saiba o que fazer e como denunciar uma violência.</p>
                            </div>
                        </Link>
                    </div>
                </div>
            </section>
        </main >

    );
}