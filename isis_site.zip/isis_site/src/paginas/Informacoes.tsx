import estilos from './Informacoes.module.css'
import { Link } from 'react-router-dom'
import { useState } from 'react';

export function Informacoes() {
    const [abertoId, setAbertoId] = useState<string | null>(null);
    const toggleAccordion = (id: string) => {
        setAbertoId(abertoId === id ? null : id);
    };

    return (
        <div className={estilos.conteiner}>
            <div className={estilos.conteinerTexto}>
                <Link
                    className={estilos.link}
                    to={'/Principal'}
                >
                    <p className={estilos.subtitulo}>{'< Voltar'}</p>
                </Link>
                <h1 className={estilos.titulo}>Informações que protegem</h1>
                <p className={estilos.texto1}>A violência contra a mulher é qualquer ação ou conduta, baseada no gênero, que
                    cause morte, dano ou sofrimento físico, sexual ou psicológico. Pode ocorrer tanto no
                    âmbito público quanto no privado e é motivada pela desigualdade de poder entre homens e
                    mulheres.</p>

            </div>
            <div className={estilos.container2}>
                <div className={estilos.accordion}>
                    <div
                        className={abertoId === 'tiposViolencia' ? estilos.headerAberto : estilos.header}
                        onClick={() => toggleAccordion('tiposViolencia')}
                    >
                        <h1 className={estilos.subtitulo1}>Tipos de violência
                            <span className={estilos.seta}>
                                {abertoId === 'tiposViolencia' ? '▲' : '▼'}
                            </span>
                        </h1>
                    </div>

                    <div className={`${estilos.corpo} ${abertoId === 'tiposViolencia' ? estilos.corpoAberto : ''}`}>
                        <p className={estilos.texto1}>
                            <h1 className={estilos.subtitulo2}>Física:</h1>
                            Qualquer conduta que ofenda a integridade corporal da vítima, como tapas, chutes,
                            empurrões, espancamentos e estrangulamento.
                            <h1 className={estilos.subtitulo2}>Psicológica:</h1>
                            Ações que causam dano emocional, isolamento, manipulação, ameaças, controle
                            excessivo, chantagem ou humilhação que prejudiquem a autoestima.
                            <h1 className={estilos.subtitulo2}>Sexual:</h1>
                            Qualquer ato sexual não consentido obtido por meio de força, coerção, ou quando a
                            mulher é forçada a realizar ou presenciar atos indesejados (inclusive impedimento
                            ao uso de contraceptivos).
                            <h1 className={estilos.subtitulo2}>Patrimonial:</h1>
                            Retenção, destruição, subtração ou controle de bens, recursos econômicos,
                            instrumentos de trabalho ou documentos pessoais da vítima.
                            <h1 className={estilos.subtitulo2}>Moral:</h1>
                            Qualquer conduta que configure calúnia, difamação ou injúria, como ofender a
                            honra, espalhar boatos ou xingar a mulher.
                        </p>
                    </div>
                </div>

                <div className={estilos.accordion}>
                    <div
                        className={abertoId === 'comoSaber' ? estilos.headerAberto : estilos.header}
                        onClick={() => toggleAccordion('comoSaber')}
                    >
                        <span className={estilos.subtitulo1}>Como saber se estou em uma situação de violência?</span>
                        <span className={estilos.seta}>
                            {abertoId === 'comoSaber' ? '▲' : '▼'}
                        </span>
                    </div>

                    <div className={`${estilos.corpo} ${abertoId === 'comoSaber' ? estilos.corpoAberto : ''}`}>
                        <p className={estilos.texto1}>
                            ● A pessoa a deixa com medo? Você teme que ela a agrida ou agrida seus
                            filhos? Ela se desculpa e diz que não fará mais? <br />
                            ● A xinga, diminui ou coloca para baixo A isola de amigos e família, proíbe de
                            ter vida social, trabalhar ou estudar? A faz sentir-se culpada ou errada? Mexe
                            no seu celular e redes sociais? <br />
                            ● Rasga suas roupas? Controla suas contas, dinheiro e cartões? Esconde seus
                            bens e documentos? Pega suas coisas sem autorização? Já quebrou suas
                            coisas de propósito? <br />
                            ● Briga com você, a deprecia publicamente, a chama de louca? A acusou de
                            traição? Espalha mentiras para que você seja mal vista? <br />
                            ● A impede de usar anticoncepcional?Já a forçou a fazer sexo sem a sua
                            vontade ou permissão? A obriga a assistir pornografia? A induz ou força a
                            avender seu corpo ou a fazer sexo com outras pessoas? A forçou a abortar
                            ou a engravidar? Já a obrigaram a se casar sem a sua vontade? <br />
                            Se você respondeu sim a algumas dessas perguntas, você está em situação de
                            violência. Afinal, a violência não é só física e pode acontecer de muitas formas.
                        </p>
                    </div>
                </div>

                <div className={estilos.accordion}>
                    <div
                        className={abertoId === 'seVocêSofre' ? estilos.headerAberto : estilos.header}
                        onClick={() => toggleAccordion('seVocêSofre')}
                    >
                        <span className={estilos.subtitulo1}>Se você sofre violência:</span>
                        <span className={estilos.seta}>
                            {abertoId === 'seVocêSofre' ? '▲' : '▼'}
                        </span>
                    </div>

                    <div className={`${estilos.corpo} ${abertoId === 'seVocêSofre' ? estilos.corpoAberto : ''}`}>
                        <p className={estilos.texto1}>

                            <h1 className={estilos.subtitulo2}>A culpa não é sua!</h1>
                            Procure sua rede de apoio, como amigos e familiares que a acolham e cuidem
                            sempre que precisar.
                            <h1 className={estilos.subtitulo2}>Procure ajuda especializada!</h1>
                            Conheça os órgãos públicos de atendimento às mulheres em situação de violência,
                            serviços de assistência e apoio de organizações da sociedade civil e aplicativos
                            preparados para ajudá-la a sair do ciclo de violência.
                            <h1 className={estilos.subtitulo2}>Você também pode usar o serviço 180!</h1>
                            O atendimento às mulheres funciona 24h por dia e oferece informações sore o que
                            fazer, onde ir e como denunciar uma violência.
                            <h1 className={estilos.subtitulo2}>Denuncie quando se sentir preparada!</h1>
                            Vá até a delegacia da mulher ou à delegacia mais esperto da sua casa e, sempre
                            que possível, vá acompanhada.
                        </p>
                    </div>
                </div>

                <div className={estilos.accordion}>
                    <div
                        className={abertoId === 'sofriViolencia' ? estilos.headerAberto : estilos.header}
                        onClick={() => toggleAccordion('sofriViolencia')}
                    >
                        <span className={estilos.subtitulo1}>Sofri violência. O que eu faço?</span>
                        <span className={estilos.seta}>
                            {abertoId === 'sofriViolencia' ? '▲' : '▼'}
                        </span>
                    </div>

                    <div className={`${estilos.corpo} ${abertoId === 'sofriViolencia' ? estilos.corpoAberto : ''}`}>
                        <p className={estilos.texto1}>
                            <h1 className={estilos.subtitulo2}>Sofri violência moral ou psicológica. O que eu faço?</h1>
                            1. Procure ajuda especializada: Existem serviços públicos e organizações
                            sociais que oferecem apoio psicológico. <br />
                            2. Junte provas: Quanto mais provas conseguir juntar, melhor. Podem ser
                            laudos médicos e/ou psicológicos, depoimentos de amigas(os), familiares ou
                            colegas de trabalho.<br />
                            3. Faça um boletim de ocorrência: Denunciar não é uma decisão fácil e é
                            fundamental que você esteja preparada para os próximos passos. Vá até a
                            delegacia da mulher mais próxima e, sempre que possível, vá acompanhada
                            de um(a) advogado(a) ou defensor(a) público(a).<br />
                            <br />

                            <h1 className={estilos.subtitulo2}>
                                Sofri assédio. O que eu faço?
                            </h1>
                            1. Junte provas: Anote o endereço onde o crime ocorreu, o nome, o contato de
                            possíveis testemunhas e, se tiver marcas físicas de agressão, tire fotos. se o
                            fato ocorreu no transporte público, anote o horário, número do ônibus e da
                            linhas. Se o agressor for desconhecido, anote detalhes para ajudar na
                            identificação.<br />
                            2. Faça um boletim de ocorrência: Vá até a delegacia da mulher ou a
                            delegacia mais próxima, de preferência com um(a) advogado(a) ou
                            defensor(a) público(a). Peça ao(a) delegado(a) uma ordem para a realização
                            do exame do corpo de delito, ele será importante para os próximos passos.<br />
                            3. Procure ajuda especializada: Existem serviços públicos e organizações
                            sociais que oferecem apoio psicológico.<br /><br />
                            <h1 className={estilos.subtitulo2}>
                                Sofri violência sexual ou física. O que eu faço?
                            </h1>
                            1. Reúna provas: Tenhas o contato de testemunhas, tire fotos das marcas
                            físicas da agressão, registre o endereço onde os fatos ocorreram e anote
                            detalhes que possam ajudar na identificação do agressor.<br />
                            2. Procure um serviço de saúde: Em caso e violência sexual, não tome
                            banho, procure um tratamento para prevenção de doenças sexualmente
                            transmissíveis, HIV e gravidez, preferencialmente, em até 72 horas. No caso
                            de violência física, faça um exame de corpo de delito.<br />
                            3. Faça um boletim de ocorrência: Vá à delegacia da mulher ou qualquer
                            outra delegacia, de preferência acompanhada de um(a) advogado(a) ou
                            defensor(a) público(a). Peça uma ordem para realizar o exame de corpo de
                            delito.<br />
                            4. Faça o exame de corpo de delito: Esse exame vai documentar a extensão
                            e a gravidade dos danos físicos e psicológicos causados a você. Ele é muito
                            importante para os próximos passos, já que o laudo será encaminhado às
                            autoridades que usarão as informações no processo.<br />
                            5. Procure ajuda especializada: Confira a lista de serviços públicos e
                            organizações sociais que oferecem apoio e acolhimento no final desta
                            página.<br /><br />
                            <h1 className={estilos.subtitulo2}>
                                Sofri violência no ambiente digital. O que faço?
                            </h1>
                            (A divulgação de vídeo ou foto de cena de sexo, nudez ou pornografia sem o
                            consetimento da vítima, além de compartilhar cenas de estupro, é crime.)<br />
                            1. Faça um print: Guarde fotos, conversas de WhatsApp e ameaças à sua
                            dignidade.<br />
                            2. Salve os links das páginas: Guarde os links da página que a agressão
                            aparece e também do perfil do agressor.<br />
                            3. Denuncie: Acesse o site Safernet, no endereço
                            https://new.safernet.org.br/denuncie<br />
                            4. Faça um boletim de ocorrência: Se sua cidade tiver delegacias
                            especializadas em crimes virtuais, ainda melhor.<br />
                            5. Informe as autoridades responsáveis: Fale com a Defensoria Pública e o
                            Ministério Público sobre a ocorrência para ser bem amparada pelas leis.
                        </p>
                    </div>
                </div>

                <div className={estilos.accordion}>
                    <div
                        className={abertoId === 'leisProtecao' ? estilos.headerAberto : estilos.header}
                        onClick={() => toggleAccordion('leisProtecao')}
                    >
                        <span className={estilos.subtitulo1}>Leis de proteção e enfrentamento à violência para mulheres:</span>
                        <span className={estilos.seta}>
                            {abertoId === 'leisProtecao' ? '▲' : '▼'}
                        </span>
                    </div>

                    <div className={`${estilos.corpo} ${abertoId === 'leisProtecao' ? estilos.corpoAberto : ''}`}>
                        <p className={estilos.texto1}>
                            <h1 className={estilos.subtitulo2}>Lei Maria da Penha (Lei nº 11.340/2006):</h1>
                            Principal mecanismo de prevenção e punição da violência doméstica e familiar. Tipifica as violências
                            física, psicológica, sexual, patrimonial e moral.
                            <h1 className={estilos.subtitulo2}>Lei do Feminicídio (Lei nº 13.104/2015):</h1>
                            Classifica o assassinato de mulheres por razões de gênero como homicídio qualificado, tornando-o crime
                            hediondo.
                            <h1 className={estilos.subtitulo2}>Lei de Importunação Sexual (Lei nº 13.718/2018):</h1>
                            Tipifica o ato libidinoso praticado sem consentimento com o objetivo de satisfazer o próprio desejo
                            (ex: toques indesejados ou cantadas agressivas no transporte público).
                            <h1 className={estilos.subtitulo2}>Lei do Stalking (Lei nº 14.132/2021):</h1>
                            Criminaliza a perseguição insistente que ameaça a integridade física ou psicológica da mulher.
                        </p>
                    </div>
                </div>

                <div className={estilos.accordion}>
                    <div
                        className={abertoId === 'orgaosPublicos' ? estilos.headerAberto : estilos.header}
                        onClick={() => toggleAccordion('orgaosPublicos')}
                    >
                        <span className={estilos.subtitulo1}>Órgãos públicos de atendimento às mulheres em situação de violência:</span>
                        <span className={estilos.seta}>
                            {abertoId === 'orgaosPublicos' ? '▲' : '▼'}
                        </span>
                    </div>

                    <div className={`${estilos.corpo} ${abertoId === 'orgaosPublicos' ? estilos.corpoAberto : ''}`}>
                        <p className={estilos.texto1}>
                            <h1 className={estilos.subtitulo2}>Delegacias de Defesa da Mulher (DDM):</h1>
                            Órgãos policiais especializados no atendimento das violências cometidas contra as mulheres.
                            <h1 className={estilos.subtitulo2}>Centros de Referência e Atendimento As Mulheres(CRAM)</h1>
                            Serviços socioassistencial, psicológico e orientação jurídica às mulheres em
                            situação de violência.
                            <h1 className={estilos.subtitulo2}>Centros de Referencia Especializados Em Assitência Social(CREAS):</h1>
                            Serviço e atendimento multidisciplinar, por meio da
                            política de assistência social para meninas e mulheres em situação de
                            violência.
                            <h1 className={estilos.subtitulo2}>Juizados Especiais de Violências Doméstica e Familiar Contra a Mulher:</h1>
                            Processam, julgam e executam as causas decorrentes da prática de
                            violências doméstica e familiar contra as mulheres.
                            <h1 className={estilos.subtitulo2}>Abrigos e Casas de Passagem:</h1>
                            Locais seguros que oferecem abrigo
                            protegido e atendimento integral às mulheres.
                            <h1 className={estilos.subtitulo2}>Defensoria Pública (Núclleo Especializado da Mulher)</h1>
                            Presta assistência jurídica integral e gratuita.
                            <h1 className={estilos.subtitulo2}>Serviços de Saúde e Centros de Pericia Medico-Legal Especializados:</h1>
                            Serviços e assistências social e psicológica, em especial para violências sexual e física, para exames e tratamento.
                            <h1 className={estilos.subtitulo2}>Ministério Público</h1>
                            Fiscaliza os serviços e a aplicação da lei.
                            <h1 className={estilos.subtitulo2}>Grupos Reflexivos para Homens</h1>
                            Espaços de educação e reabilitação de homens autores de violência.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    )
}