import estilos from './GerenciarSenha.module.css'
import { Link } from 'react-router-dom'
import cadeado from '../assets/icones/cadeado.png'
import lapis from '../assets/icones/lapis.png'

export function GerenciarSenha() {
    return (

        <div className={estilos.conteiner}>
            <Link
                to={'/principal/perfil'}
                className={estilos.link}
            >
                <p className={estilos.texto}>{'<'} Voltar</p>
            </Link>

            
            <h1 className={estilos.titulo}>Gerenciar senha</h1>
            <div className={estilos.conteinerCentro}>
                <div>
                    <p className={estilos.tituloCampo}>Senha atual</p>
                    <div className={estilos.campo}>
                        <img
                            className={estilos.icones}
                            src={cadeado} />
                        <input
                            className={estilos.texto}
                            placeholder='Crie uma senha segura'
                        />
                    </div>
                </div>

                <div>
                    <p className={estilos.tituloCampo}>Nova senha</p>
                    <div className={estilos.campo}>
                        <img
                            className={estilos.icones}
                            src={cadeado} />
                        <input
                            className={estilos.texto}
                            placeholder='Confirme sua senha'
                        />
                    </div>
                </div>
                <div>
                    <p className={estilos.tituloCampo}>Confirmar nova senha</p>
                    <div className={estilos.campo}>
                        <img
                            className={estilos.icones}
                            src={cadeado} />
                        <input
                            className={estilos.texto}
                            placeholder='Confirme sua senha'
                        />
                    </div>
                </div>

                <button className={estilos.botao}>
                        <img
                            className={estilos.icones}
                            src={lapis} />
                    Salvar alterações
                </button>
            </div>
        </div>
    )
}