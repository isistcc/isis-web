import estilos from './Conta.module.css'
import { Link } from 'react-router-dom'
import logo from '../assets/imagens/Logo.png'

import usuario from '../assets/icones/usuario.png'
import email from '../assets/icones/email.png'
import calendario from '../assets/icones/calendario.png'
import lapis from '../assets/icones/lapis.png'

export function Conta() {
    return (

        <div className={estilos.conteiner}>
            <Link
                to={'/principal/perfil'}
                className={estilos.link}
            >
                <p className={estilos.texto}>{'<'} Voltar</p>
            </Link>

            
            <h1 className={estilos.titulo}>Minha Conta</h1>
            <div className={estilos.conteinerCentro}>
                <div className={estilos.conteinerImagem}>
                    <img src={logo} className={estilos.imagem} />
                </div>

                <div>
                    <p className={estilos.tituloCampo}>Nome</p>
                    <div className={estilos.campo}>
                        <img
                            className={estilos.icones}
                            src={usuario} />
                        <input
                            className={estilos.texto}
                            placeholder='Fulana Silva'
                        />
                    </div>
                </div>

                <div>
                    <p className={estilos.tituloCampo}>Email</p>
                    <div className={estilos.campo}>
                        <img
                            className={estilos.icones}
                            src={email} />
                        <input
                            className={estilos.texto}
                            placeholder='fulanasilva@gmail.com'
                        />
                    </div>
                </div>
                <div>
                    <p className={estilos.tituloCampo}>Data de nascimento</p>
                    <div className={estilos.campo}>
                        <img
                            className={estilos.icones}
                            src={calendario} />
                        <input
                            className={estilos.texto}
                            placeholder='dd/mm/aaaa'
                        />
                    </div>
                </div>

                <button className={estilos.botao}>
                        <img
                            className={estilos.icones}
                            src={lapis} />
                    Salvar alterações
                </button>
            </div>
        </div>
    )
}