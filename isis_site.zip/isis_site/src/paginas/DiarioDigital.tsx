import estilos from './DiarioDigital.module.css'
import { Link, useNavigate} from 'react-router-dom'

import cofre from './../assets/icones/cofre.png'
import feliz from './../assets/icones/risada.png'
import bem from './../assets/icones/sorrir.png'
import neutra from './../assets/icones/inexpressivo.png'
import triste from './../assets/icones/desapontado.png'
import irritada from './../assets/icones/nervoso.png'
import autocuidado from './../assets/icones/autocuidado.png'
import brilhos from './../assets/icones/brilhos.png'
import coracao from './../assets/icones/coracao.png'
import estrela from './../assets/icones/estrela.png'
import livro from './../assets/icones/livro.png'
import maleta from './../assets/icones/maleta.png'
import pessoas from './../assets/icones/pessoas.png'

import { FiPaperclip } from "react-icons/fi";
import { HiOutlinePencil } from "react-icons/hi2";
import { LuPencilLine } from "react-icons/lu";
import { TbTrashX } from "react-icons/tb";


export function DiarioDigital() {

    
    const navegacao = useNavigate()

    const cuidadoComigo = () => {
    navegacao('/principal/cuidadoComigo')
}

const redes = () => {
    navegacao('/principal/redes')
}

const sonhosMetas = () => {
    navegacao('/principal/sonhosMetas')
}

const conhecimento = () => {
    navegacao('/principal/conhecimento')
}

const autonomiaIndependencia = () => {
    navegacao('/principal/autonomiaIndependencia')
}

    return (
        <div className={estilos.conteiner}>
            <Link
                className={estilos.link}
                to={'/principal'}
            >
                <p className={estilos.texto1}>{'< Voltar'}</p>
            </Link>
            <h1 className={estilos.titulo}>Diario Digital</h1>
            <p className={estilos.texto1}>Registre seus dias, sentimentos e progressos. Escrever pode ajudar você a se fortalecer e acompanhar sua jornada.</p>

            <div className={estilos.cartao}>
                <img
                    src={cofre}
                    className={estilos.imagem}
                />
                <div>
                    <h1 className={estilos.subtitulo1}>Cofre digital</h1>
                    <p className={estilos.texto2}>Faça upload de fotos, aúdios e documentos que apenas você terá acesso.</p>
                </div>
            </div>


            <div className={estilos.cartao}>
                <FiPaperclip
                    size={40}
                    color="var(--cor-primaria-base)"
                />
                <div>
                    <p className={estilos.texto2}>Clique aqui para anexar suas fotos, vídeos ou documentos...</p>
                </div>
            </div>



            <div className={estilos.cartaoHumor}>
                <div>
                    <h1 className={estilos.subtitulo1}>Como você está hoje?</h1>
                    <p className={estilos.texto1}>
                        Escolha seu estado de espírito
                    </p>
                </div>

                <div className={estilos.lista}>
                    <div className={estilos.conteinerIcones}>
                        <img src={feliz}
                            className={estilos.icones}
                        />
                        <p className={estilos.subtitulo2}>Feliz</p>
                    </div>
                    <div className={estilos.conteinerIcones}>
                        <img src={bem}
                            className={estilos.icones}
                        />
                        <p className={estilos.subtitulo2}>Bem</p>
                    </div>
                    <div className={estilos.conteinerIcones}>
                        <img src={neutra}
                            className={estilos.icones}
                        />
                        <p className={estilos.subtitulo2}>Neutra</p>
                    </div>
                    <div className={estilos.conteinerIcones}>
                        <img src={triste}
                            className={estilos.icones}
                        />
                        <p className={estilos.subtitulo2}>Triste</p>
                    </div>
                    <div className={estilos.conteinerIcones}>
                        <img src={irritada}
                            className={estilos.icones}
                        />
                        <p className={estilos.subtitulo2}>Irritada</p>
                    </div>
                </div>
            </div>

            <div className={estilos.cartaoHumor}>
                <h1 className={estilos.subtitulo1}>Escreva sobre seu dia</h1>
                <div className={estilos.campo}>

                    <p className={estilos.texto1}>Como foi o seu dia? Conte o que sente, o que aconteceu ou o que deseja lembrar...</p>
                </div>

                <div className={estilos.lista}>
                    <button className={estilos.botao}>
                        <HiOutlinePencil
                            size={40}
                            color="var(--cor-terciaria-fundo)"
                        />
                        <h3>
                            Salvar registro
                        </h3>
                    </button>
                </div>
            </div>

            <h1 className={estilos.subtitulo1}>Seus registros</h1>
            <div className={estilos.cartao}>
                <div className={estilos.conteinerIcones}>
                    <img
                        src={feliz}
                        className={estilos.icones}
                    />
                </div>
                <div>
                    <p className={estilos.data}>10 de junho de 2026</p>
                    <p className={estilos.texto2}> Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum harum, aliquid tempora magni maiores laudantium, eveniet at fugit deserunt veritatis, eaque nulla nam? Corporis blanditiis nostrum alias explicabo quisquam obcaecati.</p>
                    <div className={estilos.lista}>
                        <div className={estilos.opcoesRegistro}>
                            <LuPencilLine
                                size={40}
                                color="var(--cor-primaria-escura)"
                            /> <h2>Editar</h2>
                        </div>

                        <div className={estilos.opcoesRegistro}>
                            <TbTrashX
                                size={40}
                                color="var(--cor-primaria-escura)"
                            /> <h2>Excluir</h2>

                        </div>
                    </div>
                </div>
            </div>
            <h1 className={estilos.subtitulo1}>Etapas do seu plano de reconstrução</h1>

            <button 
                className={estilos.cartao}
                onClick={cuidadoComigo}
            >
                <div className={estilos.conteinerIconesRosa}>
                    <img src={autocuidado}
                        className={estilos.imagem}
                    />
                </div>
                <div>
                    <h3 className={estilos.subtitulo1}>Cuidado Comigo</h3>
                    <p className={estilos.texto1}>Priorize sua saúde mental e física.
Reconheça seu valor e pratique o autocuidado.</p>
                </div>
            </button>

            <button 
                className={estilos.cartao}
                onClick={conhecimento}
            >
                <div className={estilos.conteinerIconesRoxo}>
                    <img src={livro}
                        className={estilos.imagem}
                    />
                </div>
                <div>
                    <h3 className={estilos.subtitulo1}>Conhecimento e informação</h3>
                    <p className={estilos.texto1}>Aprenda sobre seus direitos, tipos de violência
                        e como se proteger.</p>
                </div>
            </button>

            <button 
                className={estilos.cartao}
                onClick={autonomiaIndependencia}
            >
                <div className={estilos.conteinerIconesRosa}>
                    <img src={maleta}
                        className={estilos.imagem}
                    />
                </div>
                <div>
                    <h3 className={estilos.subtitulo1}>Autonomia e independência</h3>
                    <p className={estilos.texto1}>Conquiste autonomia financeira, profissional
                        e fortaleça sua independência.</p>
                </div>
            </button>

            <button 
                className={estilos.cartao}
                onClick={redes}
            >
                <div className={estilos.conteinerIconesRoxo}>
                    <img src={pessoas}
                        className={estilos.imagem}
                    />
                </div>
                <div>
                    <h3 className={estilos.subtitulo1}>Rede de apoio</h3>
                    <p className={estilos.texto1}>Construa e fortaleça seua rede de apoio
                        com pessoas que te acolhem.</p>
                </div>
            </button>

            <button 
                className={estilos.cartao}
                onClick={sonhosMetas}
            >
                <div className={estilos.conteinerIconesRosa}>
                    <img src={estrela}
                        className={estilos.imagem}
                    />
                </div>
                <div>
                    <h3 className={estilos.subtitulo1}>Novos sonhos e metas</h3>
                    <p className={estilos.texto1}>Recome, realize seus sonhos e construa
                        o futuro que voçê merece.</p>
                </div>
            </button>

            <div className={estilos.conteinerRoxo}>
                <div className={estilos.conteinerIconeRoxo}>
                    <img src={brilhos}
                        className={estilos.imagem}
                    />
                </div>
                <div>
                    <h3 className={estilos.subtitulo1}>Motivação do dia</h3>
                    <p className={estilos.texto1}>Você já enfrentrou muitas coisas e sobreviveu.
                        Você é mais forte do que imagina.</p>
                </div>
                <div className={estilos.direita}>
                    <img src={coracao} className={estilos.imagem} />
                </div>
            </div>
        </div>
    )
}