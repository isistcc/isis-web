import estilos from './Sobre.module.css'

import botao from '../assets/icones/botaoRosa.png';
import diario from '../assets/icones/diario.png';
import chat from '../assets/icones/chatRosa.png';
import loc from '../assets/icones/loc.png';
import info from '../assets/icones/infoRosa.png';

import luane from '../assets/imagens/Luane.jpeg'
import milena from '../assets/imagens/Milena.jpg'

export function Sobre() {

    return (
        <div className={estilos.conteiner}>

            <h1 className={estilos.titulo}>Conheça nossa plataforma</h1>
            <p className={estilos.texto1}>A plataforma Ísis é um Projeto de Conclusão de Curso (TCC) de duas alunas da Etec <br />
                de Hortolândia que visa o suporte emocional e psicológico para mulheres vítimas de violência.</p>


            <h1 className={estilos.subtitulo1}>Nossos recursos e ferramentas</h1>
            <div className={estilos.conteinerCartao}>
                <div className={estilos.conteinerIcones}>
                    <img src={botao}
                        className={estilos.icones}
                    />
                </div>
                <div>
                    <h1 className={estilos.subtitulo2}>Botão de pânico</h1>
                    <p className={estilos.texto2}>Permite que a usuária solicite ajuda rapidamente em situações de emergência, <br />
                        oferecendo acesso imediato a contatos e recursos de proteção e suporte.</p>
                </div>
                <p className={estilos.seta}>{'>'}</p>
            </div>

            <div className={estilos.conteinerCartao}>
                <div className={estilos.conteinerIcones}>
                    <img src={diario}
                        className={estilos.icones}
                    />
                </div>
                <div>
                    <h1 className={estilos.subtitulo2}>Diário digital</h1>
                    <p className={estilos.texto2}>Permite que a usuária registre sentimentos, experiências e conquistas de forma <br />
                        privada e segura. A ferramenta auxilia no acompanhamento do bem-estar <br />
                        emocional e no processo de recuperação e autoconhecimento.</p>
                </div>
                <p className={estilos.seta}>{'>'}</p>
            </div>

            <div className={estilos.conteinerCartao}>
                <div className={estilos.conteinerIcones}>
                    <img src={chat}
                        className={estilos.icones}
                    />
                </div>
                <div>
                    <h1 className={estilos.subtitulo2}>Chat de Conversa</h1>
                    <p className={estilos.texto2}>Permite que a usuária converse de forma segura e acolhedora com profissionais ou pessoas capacitadas para oferecer apoio emocional, orientação e escuta durante momentos difíceis.</p>
                </div>
                <p className={estilos.seta}>{'>'}</p>
            </div>

            <div className={estilos.conteinerCartao}>
                <div className={estilos.conteinerIcones}>
                    <img src={loc}
                        className={estilos.icones}
                    />
                </div>
                <div>
                    <h1 className={estilos.subtitulo2}>Redes de apoio</h1>
                    <p className={estilos.texto2}>
                        Permite que a usuária localize facilmente serviços de suporte próximos, como delegacias, hospitais, centros de acolhimento e instituições de assistência, por meio de um mapa interativo e ferramentas de pesquisa.
                    </p>
                </div>
                <p className={estilos.seta}>{'>'}</p>
            </div>

            <div className={estilos.conteinerCartao}>
                <div className={estilos.conteinerIcones}>
                    <img src={info}
                        className={estilos.icones}
                    />
                </div>
                <div>
                    <h1 className={estilos.subtitulo2}>Informações que protegem</h1>
                    <p className={estilos.texto2}>
                        Reúne conteúdos educativos sobre violência, direitos das mulheres, medidas de proteção e formas de buscar ajuda. A página tem como objetivo informar, conscientizar e orientar as usuárias de maneira simples e acessível.
                    </p>
                </div>
                <p className={estilos.seta}>{'>'}</p>
            </div>

            <h1 className={estilos.subtitulo1}>Nossa Equipe</h1>
            <div className={estilos.conteinerEquipe}>
                <div className={estilos.conteinerImagem}>
                    <img src={luane}
                        className={estilos.imagem}
                    />
                    <h1 className={estilos.subtitulo2}>Luane Caroline da Silva</h1>
                </div>
                <div className={estilos.conteinerImagem}>
                    <img src={milena}
                        className={estilos.imagem}
                    />
                    <h1 className={estilos.subtitulo2}>Milena Vaz de Abreu</h1>
                </div>
            </div>
        </div>
    )
}