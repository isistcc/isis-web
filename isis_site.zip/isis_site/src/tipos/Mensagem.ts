export interface Mensagem {
    texto: string
    remetente: string
    criadoEm: string
}