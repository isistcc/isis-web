export type FiltrosState = {
    hospitais: boolean;
    delegacias: boolean;
    advogados: boolean;
};

export type TipoLocal = keyof FiltrosState;

export type LocalTipo = {
    id: string;
    nome: string;
    tipo: TipoLocal;
    lat: number;
    lng: number;
};