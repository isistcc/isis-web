import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Login } from '../paginas/Login'
import { Principal } from '../componentes/layout/Principal'
import { Inicial } from '../paginas/Inicial'
import { NovoUsuario } from '../paginas/NovoUsuario'
import { BotaoPanico } from '../paginas/BotaoPanico'
import { DiarioDigital } from '../paginas/DiarioDigital'
import { Chat } from '../paginas/Chat'
import { Perfil } from '../paginas/Perfil'
import { Conta } from '../paginas/Conta'
import { GerenciarSenha } from '../paginas/GerenciarSenha'
import { ChatSala } from '../paginas/ChatSala'
import { RedesApoio } from '../paginas/RedesApoio'
import { Informacoes } from '../paginas/Informacoes'
import { Sobre } from '../paginas/Sobre'
import { CuidadoComigo } from '../paginas/CuidadoComigo'
import { AutonomiaIndependencia } from '../paginas/AutonomiaIndependencia'
import { Redes } from '../paginas/Redes'
import { Conhecimento } from '../paginas/Conhecimento'
import { SonhosMetas } from '../paginas/SonhosMetas'

import { RotaProtegida } from './RotaProtegida'



export function Rotas() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path='/' element={<Login />} />
                <Route path='usuario' element={<NovoUsuario />} />

                <Route path='principal' element={<RotaProtegida><Principal /></RotaProtegida>} >
                    <Route index element={<RotaProtegida><Inicial /></RotaProtegida>} />
                    <Route path='botaoPanico' element={<RotaProtegida><BotaoPanico /></RotaProtegida>} />
                    <Route path='redesApoio' element={<RotaProtegida><RedesApoio /></RotaProtegida>} />
                    <Route path='informacoes' element={<RotaProtegida><Informacoes /></RotaProtegida>} />
                    <Route path='sobre' element={<RotaProtegida><Sobre /></RotaProtegida>} />

                    <Route path='perfil' element={<RotaProtegida><Perfil /></RotaProtegida>} />
                    <Route path='conta' element={<RotaProtegida><Conta /></RotaProtegida>} />
                    <Route path='gerenciarSenha' element={<RotaProtegida><GerenciarSenha /></RotaProtegida>} />

                    <Route path='chat' element={<RotaProtegida><Chat /></RotaProtegida>} />
                    <Route path='chatPopular/:salaId' element={<RotaProtegida><ChatSala /></RotaProtegida>} />


                    <Route path='diario' element={<RotaProtegida><DiarioDigital /></RotaProtegida>} />
                    <Route path='cuidadoComigo' element={<RotaProtegida><CuidadoComigo /></RotaProtegida>} />
                    <Route path='autonomiaIndependencia' element={<RotaProtegida><AutonomiaIndependencia /></RotaProtegida>} />
                    <Route path='redes' element={<RotaProtegida><Redes /></RotaProtegida>} />
                    <Route path='conhecimento' element={<RotaProtegida><Conhecimento /></RotaProtegida>} />
                    <Route path='sonhosMetas' element={<RotaProtegida><SonhosMetas /></RotaProtegida>} />
                </Route>
            </Routes>
        </BrowserRouter>
    )
}