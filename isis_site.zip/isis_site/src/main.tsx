import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './global.css'
import App from './App.tsx'

const root = document.getElementById('root')

if (root) {

  createRoot(root).render(
    <StrictMode>
      <App />
    </StrictMode>,
  )

} else {
  console.error("Elemento 'root' não encontrado no DOM.");
}